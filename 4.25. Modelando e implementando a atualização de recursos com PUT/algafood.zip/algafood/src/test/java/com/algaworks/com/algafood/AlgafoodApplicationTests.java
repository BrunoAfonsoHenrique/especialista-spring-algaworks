package com.algaworks.com.algafood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlgafoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
