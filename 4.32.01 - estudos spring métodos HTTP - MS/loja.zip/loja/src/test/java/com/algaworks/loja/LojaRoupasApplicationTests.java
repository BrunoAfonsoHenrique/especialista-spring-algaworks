package com.algaworks.loja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaRoupasApplicationTests {

	@Test
	void contextLoads() {
	}

}
