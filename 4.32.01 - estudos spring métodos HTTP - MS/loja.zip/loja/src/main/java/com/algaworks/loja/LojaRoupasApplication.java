package com.algaworks.loja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojaRoupasApplication {

	public static void main(String[] args) {
		SpringApplication.run(LojaRoupasApplication.class, args);
	}

}
